/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ConversationArea = {
    id: string;
    topic?: string;
    occupantsByID: Array<string>;
};

