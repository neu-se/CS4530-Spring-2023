/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type InvalidParametersError = {
    code?: any;
    message: string;
};

