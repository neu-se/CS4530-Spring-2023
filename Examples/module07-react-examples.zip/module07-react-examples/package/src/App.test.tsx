import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import  { PersonalizedLikableDeletableHello } from "./App";

describe("PersonalizedLikableDeletableHello", () => {
  let deleteCalled = false;
  beforeEach(() => {
    deleteCalled = false;
    render(
      <PersonalizedLikableDeletableHello name="Ripley"
        onDelete={() => {
          deleteCalled = true;
        }}
      />
    );
  });
  test("It renders the greeting", ()=>{
    const greeting = screen.getByText(/Hello, Ripley!/);
    expect(greeting).toBeInTheDocument();
  })
  test("Like button defaults to not liked, clicking it likes, clicking again unlikes", () => {
    const likeButton = screen.getByLabelText("like");
    fireEvent.click(likeButton);
    const unLikeButton = screen.getByLabelText("unlike");
    fireEvent.click(unLikeButton);
    expect(screen.getByLabelText("like")).toBeInTheDocument();
  });
  test("Clicking the delete button calls the delete handler", ()=>{
    expect(deleteCalled).toBe(false);
    const deleteButton = screen.getByLabelText("delete");
    fireEvent.click(deleteButton);
    expect(deleteCalled).toBe(true);
  });
});
