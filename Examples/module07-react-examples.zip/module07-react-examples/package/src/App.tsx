import React, {useEffect, useState} from "react";
import logo from "./logo.svg";
import "./App.css";
import { ChakraProvider, Container, Icon, IconButton, ListIcon, ListItem, UnorderedList } from "@chakra-ui/react";
import {AiFillHeart, AiOutlineHeart, AiTwotoneDelete} from "react-icons/ai";
import axios from "axios";

export type StudentID = number;
export type Student = { studentID: number, studentName: string };
export type Course = string;
export type Grade = number;
export type CourseGrade = { course: Course, grade: Grade };
export type Transcript = { student: Student, grades: CourseGrade[] };


function PersonalizedLikableHello(props: { name: string }) {
  const [isLiked, setIsLiked] = useState(false);
  let likeButton;
  if (isLiked) {
    likeButton = (<IconButton aria-label="unlike"
        icon={<AiFillHeart />} onClick={() => setIsLiked(false)} /> );
  } else {
    likeButton = (<IconButton aria-label="like"
        icon={<AiOutlineHeart />} onClick={() => setIsLiked(true)} /> );
  }
  return (
    <div>
      Hello, {props.name}! This is React! {likeButton}
    </div>
  );
}
export function PersonalizedLikableDeletableHello(props: { name: string, onDelete: ()=>void }) {
  const [isLiked, setIsLiked] = useState(false);
  let likeButton;
  if (isLiked) {
    likeButton = (<IconButton aria-label="unlike"
                              icon={<AiFillHeart />} onClick={() => setIsLiked(false)} /> );
  } else {
    likeButton = (<IconButton aria-label="like"
                              icon={<AiOutlineHeart />} onClick={() => setIsLiked(true)} /> );
  }
  return (
      <div>
        Hello, {props.name}! This is React! {likeButton}
        <IconButton aria-label='delete' icon={<AiTwotoneDelete />} onClick={props.onDelete} />
      </div>
  );
}
export function SingleHelloApp() {
  return <PersonalizedHello name="Ripley" />;
}
export function MultiHellos() {
  const [names, setNames] = useState(["Ripley", "Avery", "Calin"]);
  return (<div>
      {names.map((eachName) => (
          <PersonalizedLikableDeletableHello name={eachName}
                                             key={eachName}
                                             onDelete={()=> setNames(names.filter(filteredName => filteredName !== eachName))}/>
      ))}
      </div>
  );
}

export function HelloWorld(){
  return <div>Hello, World!</div>
}
export function PersonalizedHello(props: {name: string}){
  return <div>Hello, {props.name}! This is React!</div>
}
export function LikeButton(){
  const [isLiked, setIsLiked] = useState(false);
  const [count, setCount] = useState(0);

  useEffect(()=>{
    console.log(`Like has been clicked ${count} times`)
  })
  if (isLiked) {
    return (<IconButton aria-label="unlike"
                              icon={<AiFillHeart />} onClick={() => setIsLiked(false)} /> );
  } else {
    return (<IconButton aria-label="like" icon={<AiOutlineHeart />} onClick={() => {
      console.log(`Pre-setCount, count=${count}`)
      setCount(count + 1)
      setIsLiked(true)
      console.log(`Post-setCount, count=${count}`)
    }} /> );
  }
}
export function useLogCountOfProp(propertyName: string, propertyValue: boolean){
  const [count, setCount] = useState(0);
  useEffect(()=>{
    if(propertyValue){
      setCount((prevCount) => prevCount + 1)
    }
  }, [propertyValue])
  useEffect(()=>{
    console.log(`Property ${propertyName} was set to true ${count} times`);
  }, [count, propertyName])
}
export function LikeButtonCustomHook(){
  const [isLiked, setIsLiked] = useState(false);
  useLogCountOfProp('isLiked', isLiked);

  // No 'count' here, just the original like button
  if (isLiked) {
    return (<IconButton aria-label="unlike" icon={<AiFillHeart />} onClick={() => setIsLiked(false)} /> );
  } else {
    return (<IconButton aria-label="like" icon={<AiOutlineHeart />} onClick={() => setIsLiked(true)} /> );
  }
}

export function LikeButtonEffectsBuggy(){
  const [isLiked, setIsLiked] = useState(false);
  const [count, setCount] = useState(0);

  useEffect(()=>{
    if(isLiked){
      setCount(count + 1)
    }
  }, [isLiked])
  useEffect(()=>{
    console.log(`Like has been clicked ${count + 1} times`)
  }, [count])

  if (isLiked) {
    return (<IconButton aria-label="unlike" icon={<AiFillHeart />} onClick={() => setIsLiked(false)} /> );
  } else {
    return (<IconButton aria-label="like" icon={<AiOutlineHeart />} onClick={() => setIsLiked(true)} /> );
  }
}
export function LikeButtonEffects(){
  const [isLiked, setIsLiked] = useState(false);
  const [count, setCount] = useState(0);

  useEffect(()=>{
    if(isLiked){
      setCount((prevCount) => prevCount + 1)
    }
  }, [isLiked])
  useEffect(()=>{
    console.log(`Like has been clicked ${count + 1} times`)
  }, [count])

  if (isLiked) {
    return (<IconButton aria-label="unlike" icon={<AiFillHeart />} onClick={() => setIsLiked(false)} /> );
  } else {
    return (<IconButton aria-label="like" icon={<AiOutlineHeart />} onClick={() => setIsLiked(true)} /> );
  }
}
// var HelloMessage = React.createClass({
//   render: function() {
//     return <div>Hello, World!</div>
//   }
// })
// class HelloMessage extends React.Component {
//   render(){
//     return <div>Hello, World!</div>
//   }
// }
// function App() {
//   return (
//     <ChakraProvider>
//       <Container>
//         <PersonalizedHello name="Ripley" />
//         <HelloMessage name="Pat" />
//         <MultiHellos />
//       </Container>
//     </ChakraProvider>
//   );
// }
// type TownController = {};
// export function CoveyTown(){
//   const [townController, setTownController] = useState<TownController>();
//   if(townController){ //Logged in
//     return <TownMap townController={townController} />
//   }
//   return <Login />
// }
// export function TownMap(props: {townController: TownController}){
//   return <div>
//     <NewConversationModal townController={props.townController} />
//     <SocialSidebar townController={props.townController} />
//   </div>
// }
// export const TownControllerContext = React.createContext<TownController | null>(null);
// export function CoveyTown(){
//   const [townController, setTownController] = useState<TownController>();
//   if(townController){ //Logged in
//     return <TownControllerContext.Provider value={townController}><TownMap /></TownControllerContext.Provider>
//   }
//   return <Login />
// }
// export default function useTownController(): TownController {
//   const ctx = useContext(TownControllerContext);
//   assert(ctx, 'TownController context should be defined in order to use this hook.');
//   return ctx;
// }

export function RestExampleHellos(){
  const [students, setStudents] = useState<Student[]>([]);
  useEffect(() => {
    async function fetchTranscriptNames(){
        const response = await axios.get(`https://rest-example.covey.town/transcripts`)
        const transcripts = (response.data) as Transcript[];
        setStudents(transcripts.map(eachResponse => eachResponse.student));
    }
    fetchTranscriptNames();
  }, []);
  return (<div>
        {students.map((eachStudent) => (
            <PersonalizedLikableDeletableHello name={eachStudent.studentName}
                                               key={eachStudent.studentID}
                                               onDelete={()=> setStudents(students.filter(filteredStudent => filteredStudent.studentID !== eachStudent.studentID))}/>
        ))}
      </div>
  );
}
function App() {
  return (
    // <PersonalizedHello name="Ripley" />
    //   <PersonalizedLikableHello name="Ripley" />
    //   <MultiHellos />
      <LikeButtonEffectsBuggy />
    //   <LikeButtonCustomHook />
    //   <RestExampleHellos />
  );
}

export default App;
