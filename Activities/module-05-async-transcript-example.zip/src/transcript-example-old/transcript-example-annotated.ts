import axios from 'axios';
import { promises as fsPromises } from 'fs';

function dataFileName(studentID:number):string {
    return `transcript-${studentID}.json`
}

// works on any array of summable things.
function sum(numbers:any[]):number {
    return numbers.reduce((runningTotal, val) => runningTotal + val.size, 0);
}

/** returns a promise to return the student data */
// what about bad student IDs??
async function StudentDataPromise (studentID: number) : Promise<any> {
    console.log(`creating StudentDataPromise for ${studentID}`)
    const returnValue = await axios.get(`https://rest-example.covey.town/transcripts/${studentID}`)
    console.log(`StudentDataPromise for ${studentID} succeeded`)
    return returnValue
}

/** returns a promise to write the transcript file */
async function WriteTranscriptPromise(studentID: number) : Promise<void> {
    console.log(`creating WriteTranscriptPromise for ${studentID}`)
    // create a (sub)promise and wait for the result
    const response = await StudentDataPromise(studentID)
    await fsPromises.writeFile(
        dataFileName(response.data.student.studentID),        
        JSON.stringify(response.data))
    console.log(`WriteTranscriptPromise for ${studentID} succeeded`)

}



async function runClientAsync(studentIDs:number[]) {
    console.log(`Making requests for ${studentIDs}`); 
    const promisesForTranscripts = 
        studentIDs.map(studentID => WriteTranscriptPromise(studentID))     
    console.log('Promises Created!');
    await Promise.all(promisesForTranscripts);
    console.log('Files written!')
    const promisesForStats = 
        studentIDs.map(studentID => fsPromises.stat(dataFileName(studentID)))
    const stats =  await Promise.all(promisesForStats)       
    const totalSize = sum(stats)
    console.log(`Finished calculating size: ${totalSize}`);
    console.log('Done');
  }

  // these are IDs that happen to be in the db as of 11/14/22
  runClientAsync([411,412,423])

  