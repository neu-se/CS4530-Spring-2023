import axios from 'axios'

async function makeOneGetRequest(): Promise<void> {
    console.log("Making Request");
    try {
        const response = await axios.get("https://rest-example.covey.town");
        console.log("Heard back from server");
        console.log(response.data);
    } catch (err) {
        console.log('Uh oh!'); console.trace(err);
    }
}


function makeOneGetRequestNoAsync(): Promise<void> {
    console.log("Making Request");
    return axios.get("https://rest-example.covey.town")
    .then((response) => {
        console.log("Heard back from server");
        console.log(response.data);
    })
    .catch(err => {
        console.log('Uh oh!');
        console.trace(err);
    });
}
