export default async function timeIt (label:string, thunk: () => Promise<any>) {
    const t0 = performance.now();
    await thunk();    
    const t1 = performance.now()
    // const roundedTime = (Math.round((t1-t0) * 100) / 100).toFixed(2)
    const roundedTime = (t1-t0).toFixed(3)
    console.log(`Elapsed time for ${label}: ${roundedTime} milliseconds`)
    
}

