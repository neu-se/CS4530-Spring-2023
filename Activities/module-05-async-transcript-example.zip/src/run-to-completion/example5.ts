import makeRequest from './makeRequest';
import timeIt from './timeIt'

async function makeThreeConcurrentRequests() {
    const p1 : Promise<void> = makeRequest(1);
    const p2 : Promise<void> = makeRequest(2);
    const p3 : Promise<void> = makeRequest(3);
    const thePromises = [p1,p2,p3]
    await Promise.all(thePromises)
    console.log(`Main thread reports: thePromises = [${thePromises}]`)
    console.log(`Main thread finishes`)
}

timeIt("main thread", makeThreeConcurrentRequests)