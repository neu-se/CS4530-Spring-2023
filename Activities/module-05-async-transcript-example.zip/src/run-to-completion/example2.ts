import makeRequest from './makeRequest';
import timeIt from './timeIt'

async function makeThreeSimpleRequests() {
    makeRequest(1);
    makeRequest(2);
    makeRequest(3);
    console.log("Three requests made; main thread finishes")
}

timeIt("main thread", makeThreeSimpleRequests)