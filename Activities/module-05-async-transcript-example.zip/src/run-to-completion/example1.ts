import axios from 'axios';

async function makeRequest(requestNumber:number) {
    console.log(`makeRequest is about to start request ${requestNumber}`);
    const response = await axios.get('https://rest-example.covey.town');
    console.log(`makeRequest resumes request ${requestNumber}`)
    console.log(`makeRequest reports that for request '${requestNumber}', server replied: `, response.data);
}

console.log("main thread is about to call makeRequest");
makeRequest(1000);
console.log("main thread continues after makeRequest returns");
console.log("end of main thread")






