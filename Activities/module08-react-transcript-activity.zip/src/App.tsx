import {
  Badge,
  Button,
  ChakraProvider,
  Editable,
  EditableInput,
  EditablePreview,
  Grid,
  GridItem,
  HStack,
  Input,
  List,
  ListItem,
  NumberDecrementStepper,
  NumberIncrementStepper,
  NumberInput,
  NumberInputField,
  NumberInputStepper,
  Select,
  Stack,
  Stat,
  StatLabel,
  StatNumber,
  Tag,
  Wrap,
  WrapItem,
} from '@chakra-ui/react';
import React, { useEffect, useState } from 'react';
import './App.css';
import { getAllTranscripts } from './lib/client';
import { POSSIBLE_COURSES } from './types/gentrans';
import { CourseGrade, Transcript } from './types/transcript';

function GradeView({ grade }: { grade: CourseGrade }) {
  return (
    <Stat>
      <StatLabel>{grade.course}</StatLabel>
      <StatNumber>
        <Editable
          defaultValue={`${grade.grade}`}
          onSubmit={newValue => {
            console.log(`Want to update grade to ${newValue}`);
          }}>
          <EditablePreview />
          <EditableInput />
        </Editable>
      </StatNumber>
    </Stat>
  );
}
function TranscriptView({ transcript }: { transcript: Transcript }) {
  return (
    <ListItem>
      <HStack spacing='12px'>
        <Tag>{transcript.student.studentName}</Tag>
        <Badge variant='outline' colorScheme='green'>
          #{transcript.student.studentID}
        </Badge>

        {transcript.grades.map((eachGrade, eachGradeIndex) => (
          <GradeView key={eachGradeIndex} grade={eachGrade} />
        ))}
      </HStack>
    </ListItem>
  );
}
function App() {
  const [transcripts, setTranscripts] = useState<Transcript[]>([]);

  useEffect(() => {
    async function fetchTranscripts() {
      setTranscripts(await getAllTranscripts());
    }
    fetchTranscripts();
  }, []);

  return (
    <div className='App'>
      <ChakraProvider>
        <Grid templateColumns='repeat(5, 1fr)' gap={6}>
          <GridItem w='100%' h='100%' colSpan={2}>
            <div>
              <Tag>Sort by</Tag>
              <br />
              <Select
                placeholder='Select a sort order'
                onChange={option => {
                  console.log(`Selected sort order ${option.target.value}`);
                }}>
                <option value='id'>Student ID</option>
                <option value='name'>Student name</option>
                <option value='average'>Average Grade</option>
              </Select>
              <br />
              <Select
                onChange={option => {
                  console.log(`Selected sort order ${option.target.value}`);
                }}>
                <option value='asc'>Ascending</option>
                <option value='desc'>Descending</option>
              </Select>
            </div>
          </GridItem>
          <GridItem w='100%' h='100%' colSpan={1}>
            <div>
              <Tag>Add Student</Tag>
              <Stack spacing={3}>
                <Input
                  variant='outline'
                  placeholder='Student Name'
                  onChange={e => {
                    console.log(`Updated Name`);
                  }}
                />
              </Stack>
              <br />
              <Button
                colorScheme='green'
                onClick={e => {
                  console.log(`Added student!`);
                }}>
                Add Student
              </Button>
            </div>
          </GridItem>
          <GridItem w='100%' h='100%' colSpan={1}>
            <div>
              <Tag>Add Grade</Tag>
              <Stack spacing={6}>
                <Select
                  placeholder='Select option'
                  onChange={option => {
                    console.log(`Selected option`, option);
                  }}>
                  {POSSIBLE_COURSES.map(currentCourse => (
                    <option value={currentCourse} key={currentCourse}>
                      {currentCourse}
                    </option>
                  ))}
                </Select>
                <Input
                  variant='outline'
                  placeholder='Student ID'
                  onChange={e => {
                    console.log(`Added grade!`);
                  }}
                />
              </Stack>
            </div>
          </GridItem>
          <GridItem w='100%' h='100%' colSpan={1}>
            <br />
            <Stack spacing={6}>
              <NumberInput
                onChange={value => {
                  console.log('Changed! New value');
                }}>
                <NumberInputField />
                <NumberInputStepper>
                  <NumberIncrementStepper />
                  <NumberDecrementStepper />
                </NumberInputStepper>
              </NumberInput>
              <Button colorScheme='green' onClick={e => console.log('Add Toast Here!')}>
                Add Grade
              </Button>
            </Stack>
          </GridItem>
        </Grid>
        <br />
        <Wrap>
          <List spacing={6}>
            {transcripts.map(eachTranscript => (
              <WrapItem key={eachTranscript.student.studentID}>
                <TranscriptView transcript={eachTranscript} />
              </WrapItem>
            ))}
          </List>
        </Wrap>
      </ChakraProvider>
    </div>
  );
}

export default App;
